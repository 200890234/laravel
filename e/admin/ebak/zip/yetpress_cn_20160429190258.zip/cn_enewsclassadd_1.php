<?php
@include("../../inc/header.php");

/*
		SoftName : EmpireBak
		Author   : wm_chief
		Copyright: Powered by www.phome.net
*/

E_D("DROP TABLE IF EXISTS `cn_enewsclassadd`;");
E_C("CREATE TABLE `cn_enewsclassadd` (
  `classid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `classtext` mediumtext NOT NULL,
  `ttids` text NOT NULL,
  `categories` varchar(255) NOT NULL DEFAULT '',
  `column_content` text NOT NULL,
  PRIMARY KEY (`classid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8");
E_D("replace into `cn_enewsclassadd` values('1','','','','');");
E_D("replace into `cn_enewsclassadd` values('2','','','','');");
E_D("replace into `cn_enewsclassadd` values('3','','','','');");
E_D("replace into `cn_enewsclassadd` values('4','','','','');");
E_D("replace into `cn_enewsclassadd` values('5','','','','');");
E_D("replace into `cn_enewsclassadd` values('6','','','','');");
E_D("replace into `cn_enewsclassadd` values('7','关于我们页面内容','','','');");
E_D("replace into `cn_enewsclassadd` values('8','','','','');");
E_D("replace into `cn_enewsclassadd` values('9','','','','');");
E_D("replace into `cn_enewsclassadd` values('10','','','帝国cms dedecms php','');");
E_D("replace into `cn_enewsclassadd` values('11','','','','');");
E_D("replace into `cn_enewsclassadd` values('12','','','','');");
E_D("replace into `cn_enewsclassadd` values('13','','','','');");
E_D("replace into `cn_enewsclassadd` values('14','','','','');");
E_D("replace into `cn_enewsclassadd` values('15','','','','');");
E_D("replace into `cn_enewsclassadd` values('16','','','','');");
E_D("replace into `cn_enewsclassadd` values('17','','','','');");
E_D("replace into `cn_enewsclassadd` values('18','','','生活秘术 医疗健康 发财创富 博彩娱乐','');");
E_D("replace into `cn_enewsclassadd` values('19','','','','');");
E_D("replace into `cn_enewsclassadd` values('20','','','','');");
E_D("replace into `cn_enewsclassadd` values('21','','','','');");
E_D("replace into `cn_enewsclassadd` values('22','','','','');");
E_D("replace into `cn_enewsclassadd` values('23','','','','');");
E_D("replace into `cn_enewsclassadd` values('24','','','','');");
E_D("replace into `cn_enewsclassadd` values('25','','','','');");
E_D("replace into `cn_enewsclassadd` values('26','','','','');");
E_D("replace into `cn_enewsclassadd` values('27','','','','');");
E_D("replace into `cn_enewsclassadd` values('28','','','','<p>&nbsp;我们的服务</p>');");
E_D("replace into `cn_enewsclassadd` values('29','','','','');");
E_D("replace into `cn_enewsclassadd` values('30','','','','');");
E_D("replace into `cn_enewsclassadd` values('31','','','','');");
E_D("replace into `cn_enewsclassadd` values('32','','','','');");
E_D("replace into `cn_enewsclassadd` values('33','','','','');");
E_D("replace into `cn_enewsclassadd` values('34','','','','');");
E_D("replace into `cn_enewsclassadd` values('35','','','','');");
E_D("replace into `cn_enewsclassadd` values('36','','','','');");
E_D("replace into `cn_enewsclassadd` values('37','','','','');");
E_D("replace into `cn_enewsclassadd` values('38','','','','');");
E_D("replace into `cn_enewsclassadd` values('39','','','','');");
E_D("replace into `cn_enewsclassadd` values('40','','','','');");
E_D("replace into `cn_enewsclassadd` values('41','','','','');");
E_D("replace into `cn_enewsclassadd` values('42','','','','');");
E_D("replace into `cn_enewsclassadd` values('43','','','','');");
E_D("replace into `cn_enewsclassadd` values('44','','','','');");
E_D("replace into `cn_enewsclassadd` values('45','','','','');");
E_D("replace into `cn_enewsclassadd` values('46','','','','');");
E_D("replace into `cn_enewsclassadd` values('47','','','','');");
E_D("replace into `cn_enewsclassadd` values('48','','','','');");
E_D("replace into `cn_enewsclassadd` values('49','','','生活秘术 医疗健康 发财创富 博彩娱乐','');");
E_D("replace into `cn_enewsclassadd` values('50','','','','');");
E_D("replace into `cn_enewsclassadd` values('51','','','','');");
E_D("replace into `cn_enewsclassadd` values('52','','','','');");
E_D("replace into `cn_enewsclassadd` values('53','','','','');");
E_D("replace into `cn_enewsclassadd` values('54','','','帝国cms dedecms php','');");

@include("../../inc/footer.php");
?>